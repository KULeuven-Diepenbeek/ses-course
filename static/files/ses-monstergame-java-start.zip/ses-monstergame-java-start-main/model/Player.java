package model;

public class Player {
  public int hp;

  public Player(int hp) {
    this.hp = hp;
  }
}
