package model;

public class Monster {
  public int hp;

  public Monster(int hp) {
    this.hp = hp;
  }
}
