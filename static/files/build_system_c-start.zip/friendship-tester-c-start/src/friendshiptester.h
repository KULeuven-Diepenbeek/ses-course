#ifndef FRIENDSHIPTESTER_H
#define FRIENDSHIPTESTER_H

// Bereken de vriendschapscore op basis van twee namen.
// De score ligt tussen 0 en 100.
double calculate_friendship(const char *name1, const char *name2);

#endif // FRIENDSHIPTESTER_H
